import { useState } from 'react';
import Dayjs from 'dayjs'
export default function Test(){

  console.log(Dayjs().format('YYYY-MM-DD'))

  const [revealed, setRevealed] = useState(false);

  const handleReveal = () => {
    setRevealed(true);
  };

  return (
    <div className="App">
      <div className="masked-text-container">
        <div className={`mask`}></div>
        <p id="text">这是被蒙版覆盖的文字。</p>
      </div>
      <button onClick={handleReveal}>显示文字</button>
    </div>
  );

}