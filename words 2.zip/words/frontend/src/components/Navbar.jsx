import * as React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Box,
  Drawer,
  AppBar,
  CssBaseline,
  Toolbar,
  Typography,
  List, 
  ListItem, 
  ListItemButton, 
  ListItemText, 
  ListItemIcon
} from '@mui/material';

import HomeIcon from '@mui/icons-material/Home';
import HourglassTopIcon from '@mui/icons-material/HourglassTop';
import VisibilityIcon from '@mui/icons-material/Visibility';
import ReplayIcon from '@mui/icons-material/Replay';


export default function Navbar(props) {
  const {drawerWidth, content} = props
  const location = useLocation()
  const path = location.pathname
  return (
    <Box sx={{ display: 'flex' }}>
      <CssBaseline />
      <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 , backgroundColor:"rgb(118, 19, 108)"}}>
        <Toolbar>
          <Typography variant="h6" noWrap component="div">
            Our application
          </Typography>
        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: 'border-box' },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: 'auto' }}>
          <List>

            <ListItem disablePadding>
            <ListItemButton component={Link} to="/" selected={"/" === path} >
                <ListItemIcon>
                    <HomeIcon/>
                </ListItemIcon>
                <ListItemText primary={"主页"} />
            </ListItemButton>
            </ListItem>

            <ListItem disablePadding>
            <ListItemButton component={Link} to="/voc" selected={"/voc" === path} >
                <ListItemIcon>
                    <HourglassTopIcon/>
                </ListItemIcon>
                <ListItemText primary={"学新词"} />
            </ListItemButton>
            </ListItem>

            <ListItem disablePadding>
            <ListItemButton component={Link} to="/yes" selected={"/yes" === path} >
                <ListItemIcon>
                    <VisibilityIcon/>
                </ListItemIcon>
                <ListItemText primary={"回顾"} />
            </ListItemButton>
            </ListItem>

            <ListItem disablePadding>
            <ListItemButton component={Link} to="/oops" selected={"/oops" === path} >
                <ListItemIcon>
                    <ReplayIcon/>
                </ListItemIcon>
                <ListItemText primary={"复习"} />
            </ListItemButton>
            </ListItem>

          </List>
          
        </Box>
      </Drawer>
      <Box component="main" sx={{ flexGrow: 10, p: 1}}>
        <Toolbar />
        {content}

      </Box>
    </Box>
  );
}
