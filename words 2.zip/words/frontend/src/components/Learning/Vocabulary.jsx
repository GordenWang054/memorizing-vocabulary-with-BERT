import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import Dayjs from 'dayjs'
import AxiosInstance from '../Axios'


export default function Vocabulary(){
    const navigate = useNavigate()
    const [wordCount, setWordCount] = useState(0)
    const [loading, setLoading] = useState(true)
    const [vocabulary, setVocabulary] = useState()
    const getData = () => {
        AxiosInstance.get(`/memorization/corpus`).then((res) => {
            console.log(res.data)
            setVocabulary(res.data)
            setLoading(false)
            console.log(vocabulary)
        })
    }
    const submit = (countNum) => {

        AxiosInstance.patch(`memorization/corpus/${vocabulary[countNum].id}/`,{
            status: true,
            learned_times: 0,
            revision_date: Dayjs().format('YYYY-MM-DD')
        }).then(() => {
            setVocabulary(vocabulary => vocabulary.filter(item => item.id !== vocabulary[countNum].id));
            if (wordCount < vocabulary.length){
                setWordCount(wordCount-1)
            }
        })
    }
    const record = (countNum) => {
        AxiosInstance.post(`memorization/retrospection/`,{
            vocabulary: vocabulary[countNum].vocabulary,
            explanation: vocabulary[countNum].explanation,
            word_class: vocabulary[countNum].word_class,
            example: vocabulary[countNum].example,
        }).then((res) => {
            console.log(res.data)
        })
    }
    
    useEffect(() => {
        getData()
    },[])


    

    return (
        <div>
            { loading || !vocabulary ? <p>Loading data...</p>:
            vocabulary.length===0 ?<div style={{textAlign:'middle', fontSize:'30px'}}>词库里的单词都已经背完啦～</div>:
            <div>
                <ul style={{textAlign: 'left', verticalAlign: 'top', marginBottom: '30%', fontSize: '30px'}}>

                    <li className='vocabulary'>词汇：{vocabulary[wordCount].vocabulary}</li>
                    <li className='explanation'>词意：{vocabulary[wordCount].explanation}</li>
                    <li className='character'>词性：{vocabulary[wordCount].word_class}</li>
                    <li className='example'>例句：{vocabulary[wordCount].example}</li>
                </ul>
                <div style={{height:"10px", borderTop:"6px solid black", width:"100%", padding:"10px"}}></div>
                <div style={{marginTop:"10px"}}>
                    <button className='normal-button'
                        onClick={() => (
                            (wordCount<1)? alert("已经是第一个单词啦") : setWordCount(wordCount - 1),console.log(wordCount)
                        )}
                        style={{float:"left",marginRight:"10%"}}
                        >
                            上一个
                    </button>
                    <button className='normal-button'
                        onClick={() => (
                            (wordCount>=vocabulary.length-1)? alert("已经是最后一个单词啦") : setWordCount(wordCount + 1),console.log(wordCount)
                        )}>
                            下一个
                    </button>
                    <button className='animated-button'
                        onClick={() => (
                            submit(wordCount)
                            ,record(wordCount)
                        )}
                        style={{float:"right", verticalAlign:"middle"}}
                        >
                        <span>记住啦</span>
                    </button>
                </div>
            </div>
            }
        </div>
    )
}