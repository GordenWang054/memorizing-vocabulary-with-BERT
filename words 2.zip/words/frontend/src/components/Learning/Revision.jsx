import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import AxiosInstance from '../Axios'


function Form(props){
    const {handleSubmit, handleChange, answer} = props
    return (
        <form onSubmit={handleSubmit}>
                <label>
                    Answer:
                    <input type="text" name="answer" value={answer} onChange={handleChange} />
                </label>
                <br />
                <button type="submit">Submit</button>
        </form>
    )
}


export default function Revision(){
    const navigate = useNavigate()
    const [wordCount, setWordCount] = useState(0)
    const [loading, setLoading] = useState(true)
    const [vocabulary, setVocabulary] = useState()
    const [answer, setAnswer] = useState();
    const [pass, setPass] = useState()
    
    
    const handleChange = (e) => {
        setAnswer(e.target.value);
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(answer)
        AxiosInstance.post('memorization/pass', { answer:answer, id:vocabulary[wordCount].id })
            .then((res) => {
                console.log('Success:', res.data);
            })
    };
    const getData = () => {
        AxiosInstance.get(`/memorization/revision`).then((res) => {
            console.log(res.data)
            setVocabulary(res.data)
            setLoading(false)
            console.log(vocabulary)
        })
    }
    // const submit = (id, answer) => {

    //     AxiosInstance.post(`memorization/pass/`,{
    //         id: id,
    //         answer: answer,
    //     }).then((res) => {
    //         setPass(res.data.pass)

    //         setVocabulary(vocabulary => vocabulary.filter(item => item.id !== vocabulary[countNum].id));
    //         if (wordCount < vocabulary.length){
    //             setWordCount(wordCount-1)
    //         }
    //     })
    // }
    // const record = (countNum) => {
    //     AxiosInstance.post(`memorization/retrospection/`,{
    //         vocabulary: vocabulary[countNum].vocabulary,
    //         explanation: vocabulary[countNum].explanation,
    //         word_class: vocabulary[countNum].word_class,
    //         example: vocabulary[countNum].example,
    //     }).then((res) => {
    //         console.log(res.data)
    //     })
    // }
   
    useEffect(() => {
        getData()
    },[])


    

    return (
        <div>
            { loading ? <p>Loading data...</p>:
            vocabulary.length===0?<div style={{textAlign:'middle', fontSize:'30px'}}>词库里的单词都已经背完啦～</div>:
            <div>
                <ul style={{textAlign: 'left', verticalAlign: 'top', marginBottom: '30%', fontSize: '30px'}}>
                    <li className='vocabulary'>词汇：{vocabulary[wordCount].vocabulary}</li>
                    <li className='explanation'>词意：{vocabulary[wordCount].explanation}</li>
                    <li className='character'>词性：{vocabulary[wordCount].word_class}</li>
                    <li className='example'>例句：{vocabulary[wordCount].example}</li>
                    <li><Form handleChange={handleChange} handleSubmit={handleSubmit} answer={answer}/></li>
                </ul>

                <div style={{height:"10px", borderTop:"6px solid black", width:"100%", padding:"10px"}}></div>
                <div style={{marginTop:"10px"}}>
                    <button className='animated-button'
                        
                        style={{float:"left", verticalAlign:"middle"}}
                        >
                            跳过
                    </button>

                    <button className='animated-button'
                        style={{verticalAlign:"middle"}}
                        >
                        <span>记住啦</span>
                    </button>

                    <button className='normal-button'

                        style={{float:"left"}}
                        >
                        {true?<div>{wordCount+1}/{vocabulary.length}</div>:<p>hello</p>}  
                    </button>
                    
                </div>
            </div>
            }
        </div>
    )
}