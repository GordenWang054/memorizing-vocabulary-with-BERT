import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import AxiosInstance from '../Axios'


export default function Retrospection(){
    const [wordCount, setWordCount] = useState(0)
    const [loading, setLoading] = useState(true)
    const [vocabulary, setVocabulary] = useState()
    const getData = () => {
        AxiosInstance.get(`/memorization/retrospection/`).then((res) => {
            console.log(res.data)
            setVocabulary(res.data)
            setLoading(false)
            console.log(vocabulary)
        })
    }
    useEffect(() => {
        getData()
    },[])


    

    return (
        <div>
            { loading ? <p>Loading data...</p>:
            vocabulary.length===0?<div style={{textAlign:'middle', fontSize: '30px  '}}>今天还没有开始背单词哦～继续加油吧</div>:
            <div>
                <ul style={{textAlign: 'left', verticalAlign: 'top', marginBottom: '30%', fontSize: '30px'}}>
                    <li className='vocabulary'>词汇：{vocabulary[wordCount].vocabulary}</li>
                    <li className='masked-text-container'> <div className='mask' style={{width:'45%'}}></div>词意：{vocabulary[wordCount].explanation}</li>
                    <li className='masked-text-container'>词性：{vocabulary[wordCount].word_class}</li>
                    <li className='example'>例句：{vocabulary[wordCount].example}</li>
                </ul>
                <div style={{height:"10px", borderTop:"6px solid black", width:"100%", padding:"10px"}}></div>
                <div style={{marginTop:"10px"}}>
                    <button className='normal-button'
                        onClick={() => (
                            (wordCount<1)? alert("已经是第一个单词啦") : setWordCount(wordCount - 1)
                        )}
                        style={{float:"left"}}
                        >
                            上一个
                    </button>

                    <button className='normal-button'
                        >
                            {wordCount+1}/{vocabulary.length}
                    </button>

                    <button className='normal-button'
                        onClick={() => (
                            (wordCount>=vocabulary.length-1)? alert("已经是最后一个单词啦") : setWordCount(wordCount + 1)
                        )}
                        style={{float:"right"}}>
                            下一个
                    </button>
                </div>
            </div>
            }
        </div>
    )
}