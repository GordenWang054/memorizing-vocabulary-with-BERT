import Home from './components/Homepage'
import Navbar from './components/Navbar'
import Vocabulary from './components/Learning/Vocabulary'
import Retrospection from './components/Learning/Retrospection'
import Revision from './components/Learning/Revision'
import Test from './components/test'
import {BrowserRouter, Routes, Route} from 'react-router-dom'

function App() {
  const myWidth = 220
  const percentages1 = ["15%", "25%", "37%"]
  const project1 = "Timeline"
  const thread1 = "1"

  return (
    <BrowserRouter>
      <Routes>
        <Route path="" element={<Home/>}/>
        <Route path="/yes" element={<Navbar drawerWidth={myWidth} content={<Retrospection/>}/>}/>
        <Route path="/oops" element={<Navbar drawerWidth={myWidth} content={<Revision/>}/>}/>
        <Route path="/voc" element={<Navbar drawerWidth={myWidth} content={<Vocabulary/>}/>}/>
        <Route path="/test" element={<Test/>}/>
      </Routes>
    </BrowserRouter>
    
  )
}

export default App
