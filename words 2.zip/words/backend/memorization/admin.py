from django.contrib import admin
from .models import Corpus, Retrospection

# Register your models here.
admin.site.register(Corpus)
admin.site.register(Retrospection)
