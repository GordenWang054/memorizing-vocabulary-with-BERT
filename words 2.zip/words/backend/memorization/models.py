from django.db import models
from django.utils.timezone import now

# Create your models here.

class Corpus(models.Model):
    vocabulary = models.CharField(max_length=100, unique=True)
    explanation = models.TextField()
    word_class = models.CharField(max_length=100)
    example = models.TextField(blank=True, null=True)
    status = models.BooleanField(default=False)
    learned_times = models.IntegerField(default=0)
    revision_date = models.DateField(default=now, editable=True)


    def __str__(self):
        return self.vocabulary


# Create your models here.
class Retrospection(models.Model):
    vocabulary = models.CharField(max_length=100, unique=True)
    explanation = models.TextField()
    word_class = models.CharField(max_length=100)
    example = models.TextField()
    added_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.vocabulary


