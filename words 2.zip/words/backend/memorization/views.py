from django.shortcuts import render
from django.http import HttpResponse
from rest_framework import viewsets, permissions
from rest_framework.decorators import api_view, renderer_classes
from rest_framework.renderers import JSONRenderer, TemplateHTMLRenderer
from .serializers import CorpusSerializer, RetrospectionSerializer
from datetime import date, timedelta
from rest_framework.response import Response
from .models import Corpus, Retrospection
from sklearn.metrics.pairwise import paired_cosine_distances
from sentence_transformers import SentenceTransformer

# utils

gaps = [1, 2, 4, 7, 15]
def updateDate(id, times):
    record = Corpus.objects.get(id=id)
    record.revision_date += timedelta(days=gaps[times])
    record.learned_times += 1
    record.save()

model = SentenceTransformer('uer/sbert-base-chinese-nli')
def statusOfPass(sentences, times):
    passOrNot = False
    sentence_embeddings = model.encode(sentences)
    cosine_score = 1 - paired_cosine_distances([sentence_embeddings[0]],[sentence_embeddings[1]])
    print(f"The score is {cosine_score}")
    if cosine_score > 0.723:
        times += 1
        passOrNot = True
    else:
        times = 0
    return [times, passOrNot]

        

# Create your views here.



def home(request):
    return HttpResponse("Homepage")


@api_view(('GET',))
@renderer_classes((TemplateHTMLRenderer, JSONRenderer))
def getRevision(request):
    if request.method == 'GET':
        queryset = Corpus.objects.all().filter(revision_date=date.today())
        serializer = CorpusSerializer(queryset, many=True)
        return Response(serializer.data)
    else:
        pass
    
@api_view(('POST',))
@renderer_classes((TemplateHTMLRenderer, JSONRenderer))
def passTheTest(request):
    if request.method == 'POST':
        queryset = Corpus.objects.get(id=request.data['id'])
        sentences = [request.data['answer'],queryset.explanation]
        print(sentences)
        times, passOrNot = statusOfPass(sentences=sentences, times=queryset.learned_times)
        print(times)
        updateDate(request.data['id'], times)
        return Response({'pass': passOrNot})
        
        

class CorpusViewset(viewsets.ViewSet):
    permission_classes = [permissions.AllowAny]
    queryset = Corpus.objects.all()
    serializer_class = CorpusSerializer

    def list(self, request):
        queryset = self.queryset.filter(status=False)
        serializer = self.serializer_class(queryset, many=True)
        return Response(serializer.data)

    def create(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            print(serializer.errors)
            return Response(serializer.errors, status=403)

    def update(self, request, pk=None):
        corpus = self.queryset.get(pk=pk)

        print(request.data)
        serializer = self.serializer_class(corpus, data=request.data)
        if serializer.is_valid():
            print("this time here")
            serializer.save()
            return Response(serializer.data)
        else:
            print(serializer.errors)
            return Response(serializer.errors, status=400)

    def partial_update(self, request, pk=None):
        corpus = self.queryset.get(pk=pk)

        print(request.data)
        serializer = self.serializer_class(corpus, data=request.data, partial=True)
        if serializer.is_valid():
            print("this time here")
            serializer.save()
            return Response(serializer.data)
        else:
            print(serializer.errors)
            return Response(serializer.errors, status=400)

    def retrieve(self, request, pk=None):
        corpus = self.queryset.get(pk=pk)
        serializer = self.serializer_class(corpus)
        return Response(serializer.data)

    def destroy(self, request, pk=None):
        corpus = self.queryset.get(pk=pk)
        corpus.delete()
        return Response(status=204)

class RetrospectionViewset(viewsets.ViewSet):
    permission_classes = [permissions.AllowAny]
    queryset = Retrospection.objects.all()
    serializer_class = RetrospectionSerializer

    def list(self, request):
        self.queryset.filter(added_date__lt=date.today()).delete()
        queryset2 = self.queryset.filter(added_date=date.today())
        serializer = self.serializer_class(queryset2, many=True)
        return Response(serializer.data)

    def create(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        else:
            print(serializer.errors)
            return Response(serializer.errors, status=402)

    def update(self, request, pk=None):
        corpus = self.queryset.get(pk=pk)

        print(request.data)
        serializer = self.serializer_class(corpus, data=request.data)
        if serializer.is_valid():
            print("this time here")
            serializer.save()
            return Response(serializer.data)
        else:
            print(serializer.errors)
            return Response(serializer.errors, status=400)

    def partial_update(self, request, pk=None):
        corpus = self.queryset.get(pk=pk)

        print(request.data)
        serializer = self.serializer_class(corpus, data=request.data, partial=True)
        if serializer.is_valid():
            print("this time here")
            serializer.save()
            return Response(serializer.data)
        else:
            print(serializer.errors)
            return Response(serializer.errors, status=400)

    def retrieve(self, request, pk=None):
        corpus = self.queryset.get(pk=pk)
        serializer = self.serializer_class(corpus)
        return Response(serializer.data)

    def destroy(self, request, pk=None):
        corpus = self.queryset.get(pk=pk)
        corpus.delete()
        return Response(status=204)

    

