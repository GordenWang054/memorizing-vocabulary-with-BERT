from django.urls import path
from .views import home, CorpusViewset, RetrospectionViewset, getRevision, passTheTest
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register('corpus', CorpusViewset, basename='corpus')
router.register('retrospection', RetrospectionViewset, basename='retrospection')

urlpatterns = [
    path('revision', getRevision),
    path('pass', passTheTest),
]

urlpatterns += router.urls
