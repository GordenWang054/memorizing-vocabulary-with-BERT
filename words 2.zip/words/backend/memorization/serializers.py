from rest_framework import serializers
from .models import Corpus, Retrospection

class CorpusSerializer(serializers.ModelSerializer):
    class Meta:
        model = Corpus
        fields = ('id', 'vocabulary', 'explanation', 'word_class', 'example', 'status', 'learned_times', 'revision_date')
        
class RetrospectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Retrospection
        fields = ('vocabulary', 'explanation', 'word_class', 'example')
        
    